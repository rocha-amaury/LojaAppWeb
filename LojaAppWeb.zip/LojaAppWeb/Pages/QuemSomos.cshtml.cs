using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LojaAppWeb.Pages
{
    public class QuemSomosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
